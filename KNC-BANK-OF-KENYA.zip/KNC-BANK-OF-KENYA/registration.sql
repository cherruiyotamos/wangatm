CREATE DATABASE IF NOT EXISTS registration;
CREATE TABLE users(
username varchar(255) NOT NULL,
email varchar(255) NOT NULL,
password varchar(255) NOT NULL
)